import streamlit as st
import plotly.graph_objects as go
from utils import preprocess_text, analyze_sentiment, get_statistics
import os

def create_gauge_chart(value, title):
    """Create a gauge chart using plotly"""
    fig = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = value,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': title, 'font': {'size': 24}},
        gauge = {
            'axis': {'range': [-1, 1], 'tickwidth': 1},
            'bar': {'color': "#FF4B4B"},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "gray",
            'steps': [
                {'range': [-1, -0.3], 'color': "#FF4B4B"},
                {'range': [-0.3, 0.3], 'color': "#F0F2F6"},
                {'range': [0.3, 1], 'color': "#00CC96"}
            ]
        }
    ))
    fig.update_layout(
        height=250,
        margin=dict(l=10, r=10, t=40, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )
    return fig

def main():
    # Page configuration
    st.set_page_config(
        page_title="Sentiment Analysis Tool",
        layout="wide",
        initial_sidebar_state="collapsed"
    )

    # Title and description with native Streamlit markdown
    st.title("✨ Advanced Sentiment Analysis Tool")

    st.markdown("""
    <div style='background-color: #f0f2f6; padding: 1.5rem; border-radius: 10px; margin-bottom: 2rem;'>
        <h4 style='color: #262730; margin-bottom: 1rem;'>Features</h4>
        <ul style='color: #484848;'>
            <li>Multilingual support with confidence scores</li>
            <li>Advanced emotion detection</li>
            <li>Detailed sentiment metrics</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

    # Initialize session state for API key
    if "api_key_configured" not in st.session_state:
        st.session_state.api_key_configured = False

    # API key configuration in sidebar
    if not st.session_state.api_key_configured and not os.getenv('OPENAI_API_KEY'):
        with st.sidebar:
            st.warning("OpenAI API key is required for advanced analysis.")
            api_key = st.text_input("Enter your OpenAI API key:", type="password")
            if api_key:
                os.environ['OPENAI_API_KEY'] = api_key
                st.session_state.api_key_configured = True
                st.rerun()

    # Text input with custom container
    st.markdown("""
        <div style='background-color: white; padding: 1.5rem; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);'>
            <h4 style='color: #262730; margin-bottom: 1rem;'>Enter your text</h4>
        </div>
    """, unsafe_allow_html=True)

    text_input = st.text_area("", height=150, placeholder="Type or paste your text here...")

    # Analyze button with custom styling
    if st.button("🔍 Analyze Text", type="primary", use_container_width=True):
        if not text_input.strip():
            st.error("⚠️ Please enter some text to analyze.")
            return

        try:
            # Preprocess text
            processed_text = preprocess_text(text_input)

            # Get sentiment analysis
            polarity, subjectivity, sentiment, advanced_analysis = analyze_sentiment(processed_text)

            if polarity is None:
                st.error("❌ Error processing text. Please try again with valid input.")
                return

            # Results in an expander
            with st.expander("📊 Analysis Results", expanded=True):
                # Basic metrics
                st.markdown("### 🎯 Sentiment Analysis Results")

                # Metrics in columns with custom containers
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Overall Sentiment", sentiment, delta=None)
                with col2:
                    st.metric("Polarity", f"{polarity:.2f}", delta=None)
                with col3:
                    st.metric("Subjectivity", f"{subjectivity:.2f}", delta=None)

                # Gauge charts
                st.plotly_chart(create_gauge_chart(polarity, "Polarity Score"))
                st.plotly_chart(create_gauge_chart(subjectivity, "Subjectivity Score"))

                # Advanced analysis results
                if advanced_analysis:
                    st.markdown("### 🌍 Language Detection")
                    lang_data = advanced_analysis['detected_language']

                    lang_col1, lang_col2, lang_col3 = st.columns(3)
                    with lang_col1:
                        st.metric("Detected Language", lang_data['name'], delta=None)
                    with lang_col2:
                        st.metric("Language Code", lang_data['code'], delta=None)
                    with lang_col3:
                        st.metric("Confidence", f"{lang_data['confidence']:.2%}", delta=None)

                    st.markdown("### 😊 Emotional Analysis")
                    emo_col1, emo_col2, emo_col3 = st.columns(3)
                    with emo_col1:
                        st.metric("Primary Emotion", advanced_analysis['emotions']['primary'], delta=None)
                    with emo_col2:
                        st.metric("Secondary Emotion", advanced_analysis['emotions']['secondary'], delta=None)
                    with emo_col3:
                        st.metric("Emotional Intensity", f"{advanced_analysis['emotions']['intensity']:.2f}", delta=None)

                # Text statistics
                st.markdown("### 📝 Text Statistics")
                word_count, char_count, avg_word_length = get_statistics(processed_text)

                stat_col1, stat_col2, stat_col3 = st.columns(3)
                with stat_col1:
                    st.metric("Word Count", word_count, delta=None)
                with stat_col2:
                    st.metric("Character Count", char_count, delta=None)
                with stat_col3:
                    st.metric("Average Word Length", f"{avg_word_length:.1f}", delta=None)

        except Exception as e:
            st.error(f"❌ An error occurred while processing your text: {str(e)}")

if __name__ == "__main__":
    main()