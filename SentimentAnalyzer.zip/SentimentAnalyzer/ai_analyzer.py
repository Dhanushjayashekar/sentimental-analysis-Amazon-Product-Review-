import os
from openai import OpenAI
import json
from langdetect import detect, detect_langs
from langdetect.lang_detect_exception import LangDetectException

# Initialize OpenAI client
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

def get_language_name(lang_code):
    """Convert language code to full name"""
    language_names = {
        'en': 'English', 'es': 'Spanish', 'fr': 'French', 'de': 'German',
        'it': 'Italian', 'pt': 'Portuguese', 'nl': 'Dutch', 'ru': 'Russian',
        'ar': 'Arabic', 'hi': 'Hindi', 'ja': 'Japanese', 'ko': 'Korean',
        'zh': 'Chinese', 'vi': 'Vietnamese', 'th': 'Thai', 'tr': 'Turkish'
    }
    return language_names.get(lang_code, 'Unknown')

def detect_language_and_emotions(text):
    """
    Detect language using langdetect and analyze emotions using OpenAI
    """
    try:
        # Language detection
        lang_code = detect(text)
        lang_probabilities = detect_langs(text)

        detected_language = {
            "name": get_language_name(lang_code),
            "code": lang_code,
            "confidence": float(next((l.prob for l in lang_probabilities if l.lang == lang_code), 0.0))
        }

        # Emotion analysis with OpenAI
        if os.getenv('OPENAI_API_KEY'):
            try:
                response = client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {
                            "role": "system",
                            "content": """Analyze the emotional content of the text and return:
                            {
                                "emotions": {
                                    "primary": "Main emotion (e.g., joy, sadness, anger, fear, surprise)",
                                    "secondary": "Secondary emotion if present",
                                    "intensity": "Score between 0.0 and 1.0"
                                }
                            }"""
                        },
                        {"role": "user", "content": text}
                    ],
                    response_format={"type": "json_object"}
                )
                emotions_result = json.loads(response.choices[0].message.content)
                emotions = emotions_result["emotions"]
            except Exception as e:
                print(f"OpenAI API Error: {str(e)}")
                emotions = {
                    "primary": "neutral",
                    "secondary": "none",
                    "intensity": 0.0
                }
        else:
            emotions = {
                "primary": "API Key Required",
                "secondary": "none",
                "intensity": 0.0
            }

        return {
            "detected_language": detected_language,
            "emotions": emotions
        }

    except LangDetectException as e:
        return {
            "detected_language": {
                "name": "Detection Failed",
                "code": "error",
                "confidence": 0.0
            },
            "emotions": {
                "primary": "neutral",
                "secondary": "none",
                "intensity": 0.0
            }
        }