import re
from textblob import TextBlob
import pandas as pd
from ai_analyzer import detect_language_and_emotions

def preprocess_text(text):
    """
    Preprocess the input text by removing special characters and extra whitespace
    """
    if not isinstance(text, str):
        return ""

    # Remove extra whitespace
    text = ' '.join(text.split())
    return text

def analyze_sentiment(text):
    """
    Analyze the sentiment of the given text using TextBlob and OpenAI
    Returns polarity, subjectivity, sentiment label, and advanced analysis
    """
    if not text:
        return None, None, None, None

    # Basic sentiment analysis with TextBlob
    analysis = TextBlob(text)
    polarity = analysis.sentiment.polarity
    subjectivity = analysis.sentiment.subjectivity

    # Determine sentiment label
    if polarity > 0:
        sentiment = "Positive"
    elif polarity < 0:
        sentiment = "Negative"
    else:
        sentiment = "Neutral"

    # Advanced analysis with OpenAI
    advanced_analysis = detect_language_and_emotions(text)

    return polarity, subjectivity, sentiment, advanced_analysis

def get_statistics(text):
    """
    Calculate basic text statistics
    """
    if not text:
        return None, None, None

    words = text.split()
    word_count = len(words)
    char_count = len(text)
    avg_word_length = char_count / word_count if word_count > 0 else 0

    return word_count, char_count, avg_word_length